package Code;

public class logicalExpressionClass2 {

	public boolean returnInput(boolean conditiona, boolean conditionb, boolean conditionc) {

		  return (conditiona || conditionb || conditionc);
	}
}