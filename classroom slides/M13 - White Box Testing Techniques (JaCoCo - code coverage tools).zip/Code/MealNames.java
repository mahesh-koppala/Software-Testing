package Code;
public enum MealNames {breakfast, lunch, supper}
