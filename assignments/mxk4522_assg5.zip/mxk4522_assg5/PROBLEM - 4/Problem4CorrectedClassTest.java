package assignment_5.problem4;
//import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
//import junitparams.Parameters;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import assignment_5.problem4.Problem4CorrectedClass.state;




@RunWith(JUnitParamsRunner.class)
public class Problem4CorrectedClassTest {
	
	
	private Problem4CorrectedClass problem4;
	@Before
	public void setUp() throws Exception {
		
		problem4= new Problem4CorrectedClass(); 
	}

	@Test
	@FileParameters("src/assignment_5/problem4/Problem4TestCaseTable.csv")
	public void testGasPump(int TestCaseNumber, state currentState, boolean C, boolean H, boolean N, boolean S, boolean X, String D, boolean G, String NextState ) {
		problem4.gasPump(currentState, C, H, N, S, X);
		assertEquals(D,problem4.getD());
		assertEquals(G,problem4.isG());
		
	}

}
