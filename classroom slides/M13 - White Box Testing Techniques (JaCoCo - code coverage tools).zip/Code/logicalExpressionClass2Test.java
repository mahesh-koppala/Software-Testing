package Code;

import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(JUnitParamsRunner.class)
public class logicalExpressionClass2Test {

	logicalExpressionClass2 lex;
	
	@Before
	public void setUp() {
		lex = new logicalExpressionClass2();
	}

	@SuppressWarnings("unused")
	private static final Object[] parametersForlogicalExpressionClassTest () {
		return $(
//				Parameters are: (1,2,3,4)
//								1=conditiona, 2=conditionb, 3=conditionc, 4=result
//				Test case 1
				$(false, 	false,		false, 	false),
//				Test case 2
				$(true, 	false,		false, 	true),
//				Test case 2
				$(false, 	true,		false, 	true),
//				Test case 2
				$(false, 	false,		true, 	true)
		);
	}
	@Test
	@Parameters(method="parametersForlogicalExpressionClassTest")
	public void test(boolean conditiona, boolean conditionb, boolean conditionc, boolean result) {
		assertEquals(result,lex.returnInput(conditiona,conditionb,conditionc));
	}
}