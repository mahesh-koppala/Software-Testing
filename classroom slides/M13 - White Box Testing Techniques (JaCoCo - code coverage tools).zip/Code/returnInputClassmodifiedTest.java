package Code;

import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(JUnitParamsRunner.class)
public class returnInputClassmodifiedTest {

	returnInputClassmodified ricm;
	
	@Before
	public void setUp() {
		ricm = new returnInputClassmodified();
	}

	@SuppressWarnings("unused")
	private static final Object[] parametersForreturnInputClassmodifiedTest () {
		return $(
//				Parameters are: (1,2,3,4)
//								1=conditiona, 2=conditionb, 3=conditionc, 4=result
//				Test case 1
				$(true,	true,		true, 	true),
//				Test case 2
//				$(true, 	false,		false, 	true),
//				Test case 3
//				$(false, 	true,		false, 	true),
//				Test case 4
				$(false, 	false,		false, 	false)
		);
	}
	@Test
	@Parameters(method="parametersForreturnInputClassmodifiedTest")
	public void test(boolean conditiona, boolean conditionb, boolean conditionc, boolean result) {
		assertEquals(result,ricm.returnInput(conditiona,conditionb,conditionc));
	}
}