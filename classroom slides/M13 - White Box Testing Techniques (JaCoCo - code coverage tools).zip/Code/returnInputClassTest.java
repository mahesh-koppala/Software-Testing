package Code;

import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(JUnitParamsRunner.class)
public class returnInputClassTest {

	returnInputClass ric;
	
	@Before
	public void setUp() {
		ric = new returnInputClass();
	}

	@SuppressWarnings("unused")
	private static final Object[] parametersForreturnInputClassTest () {
		return $(
//				Parameters are: (1,2,3,4)
//								1=conditiona, 2=conditionb, 3=conditionc, 4=result
//				Test case 1
				$(true,		true,		true, 3),
//				Test case 2
				$(false, 	false,		false, 0)
		);
	}
	@Test
	@Parameters(method="parametersForreturnInputClassTest")
	public void test(boolean conditiona, boolean conditionb, boolean conditionc, int result) {
		assertEquals(result,ric.returnInput(conditiona,conditionb,conditionc));
	}
}