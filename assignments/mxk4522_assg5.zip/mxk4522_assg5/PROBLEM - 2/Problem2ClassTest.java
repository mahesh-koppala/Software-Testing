package assignment_5.problem2;
//import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
//import junitparams.Parameters;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;





@RunWith(JUnitParamsRunner.class)
public class Problem2ClassTest {

	    private Problem2Class problem2;                ;
	
	
	@Before
	public void setUp() throws Exception {
		
		problem2 = new Problem2Class();
		
	}

	@Test
	@FileParameters("src/assignment_5/problem2/Problem2TestCaseTable.csv")
	public void testDetermineMemberBonus(int Test_case_number, double cart, boolean First_time_buyer, boolean Gold_status,int Bonus_points, double TaxRate, double Total, boolean MemberBonus, String BasisPath, String MCDC ) {
		problem2.determineMemberBonus(cart, First_time_buyer, Gold_status, Bonus_points, TaxRate);
		assertEquals(Total,problem2.getTotal(),0.01);
		assertEquals(MemberBonus,problem2.isMemberBonus());
	}

}
