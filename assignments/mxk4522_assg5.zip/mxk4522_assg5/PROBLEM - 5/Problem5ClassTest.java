package assignment_5.problem5;
import static org.junit.Assert.assertEquals;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import easymock.TankLevelSensor;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class Problem5ClassTest {
	
	private  Problem5Class problem5;
	Problem5ServerData mockObject;

	@Before
	public void setUp() throws Exception {
		
		problem5 = new Problem5Class();
		mockObject =  EasyMock.strictMock(Problem5ServerData.class);
		
	}

	@Test
	@FileParameters("src/assignment_5/problem5/Problem3TestCaseTable.csv")
	public void testCalcTotal(int TestCaseNumber,double Total, boolean ExistingMember, boolean ValidDiscount, boolean ValidCoupon, double RETURN, String BasisPath, String MCDC) {
		EasyMock.expect(mockObject.getTotal()).andReturn(Total);
		EasyMock.replay(mockObject);
		assertEquals(RETURN,problem5.calcTotal(mockObject, ExistingMember, ValidDiscount, ValidCoupon),0.01);
		
		
		
	}

}
