package Code;

public class WorkingDayClass2 {
	
	  public void workingWeek(int theDay)
	  {
	    switch (theDay)
	    {
	      case 1:
	      case 2:
	      case 3:
	      case 4:  System.out.println(theDay+" Weekday");break;
	 
	      case 5:  System.out.println(theDay+" TGIF"); break;
	 
	      case 6:
	      case 7:  System.out.println(theDay+" Weekend!"); break;
	      default: 	System.out.println(theDay+" None of the above");
	    }
	  }
}