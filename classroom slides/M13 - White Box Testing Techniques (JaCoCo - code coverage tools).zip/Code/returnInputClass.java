package Code;

public class returnInputClass {

	public int returnInput(boolean conditiona, boolean conditionb, boolean conditionc) {
		  int x=0;
		  
		  if (conditiona)
		    x++;
		  if (conditionb)
		    x++;
		  if (conditionc)
		    x++;

		  return x;
	}
}
