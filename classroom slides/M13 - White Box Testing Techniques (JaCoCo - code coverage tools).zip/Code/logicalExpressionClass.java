package Code;

public class logicalExpressionClass {

	public boolean returnInput(boolean conditiona, boolean conditionb, boolean conditionc) {

		  return ((conditiona & conditionb) | conditionc);
	}
}
