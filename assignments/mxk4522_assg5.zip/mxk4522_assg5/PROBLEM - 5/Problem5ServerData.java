package assignment_5.problem5;

public interface Problem5ServerData {
	
	public double getTotal();
	

}
