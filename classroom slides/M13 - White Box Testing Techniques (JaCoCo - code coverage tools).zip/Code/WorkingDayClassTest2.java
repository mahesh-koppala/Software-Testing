package Code;
import org.junit.Test;

public class WorkingDayClassTest2 {

	@Test
	public void test() {
		WorkingDayClass2 wrk = new WorkingDayClass2();
		for (int day=0;day<=8;day++)
			wrk.workingWeek(day);
	}
}