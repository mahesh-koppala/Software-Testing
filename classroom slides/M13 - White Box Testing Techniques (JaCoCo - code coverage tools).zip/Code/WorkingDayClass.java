package Code;

public class WorkingDayClass {
	
	  public void workingWeek(Day theDay)
	  {
	    switch (theDay)
	    {
	      case MONDAY:
	      case TUESDAY:
//	      case WEDNESDAY:
	      case THURSDAY:  System.out.println(theDay+" Weekday");break;
	 
	      case FRIDAY:    System.out.println(theDay+" TGIF"); break;
	 
	      case SATURDAY:
	      case SUNDAY:    System.out.println(theDay+" Weekend!"); break;
//	      default: 	System.out.println(theDay+" None of the above");
	    }
	  }
}