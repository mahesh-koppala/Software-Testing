package assignment_5.problem3;
//import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
//import junitparams.Parameters;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;






@RunWith(JUnitParamsRunner.class)
public class Problem3ClassTest {
	
	
	private Problem3Class problem3;

	@Before
	public void setUp() throws Exception {
		
		
		problem3 = new Problem3Class();
	}

	@Test
	@FileParameters("src/assignment_5/problem3/Problem3TestCaseTable.csv")
	public void testCalcTotal(int TestCaseNumber,double Total, boolean ExistingMember, boolean ValidDiscount, boolean ValidCoupon, double RETURN, String BasisPath, String MCDC ) {
		problem3.calcTotal(Total, ExistingMember, ValidDiscount , ValidCoupon);
		assertEquals(RETURN,problem3.calcTotal(Total, ExistingMember, ValidDiscount , ValidCoupon),0.01);
		
	}

}
