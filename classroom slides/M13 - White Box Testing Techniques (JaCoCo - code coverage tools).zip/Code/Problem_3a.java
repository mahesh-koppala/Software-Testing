package Code;

public class Problem_3a {

	public void setAlerts (double fuel_level, Problem3Class prb3) {

		prb3.setRed_light(false);prb3.setYellow_light(false);prb3.setGreen_light(false);

		if (fuel_level<20.0)
			prb3.setGreen_light(true);
		else
			if (fuel_level<35.0)
				prb3.setYellow_light(true);
			else
				if (fuel_level<=75.0)
					prb3.setRed_light(true);
	}
}