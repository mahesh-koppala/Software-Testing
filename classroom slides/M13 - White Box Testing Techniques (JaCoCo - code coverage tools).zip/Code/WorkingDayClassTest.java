package Code;
import org.junit.Test;

public class WorkingDayClassTest {

	@Test
	public void test() {
		WorkingDayClass wrk = new WorkingDayClass();
		for (Day d:Day.values())
			wrk.workingWeek(d);
	}
}