package assignment_5.problem1;
import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;


@RunWith(JUnitParamsRunner.class)
public class Problem1ClassTest {

private Problem1Class prob1;

@Before
public void setUp () throws Exception {
prob1 = new Problem1Class();
}

@Test
@FileParameters("src/assignment_5/problem1/Problem1TestCasetable.csv")
public void testSetWarnings(int testcaseNumber, boolean cruiseEngaged, double distance, int timer, boolean redLight, boolean yellowLight, boolean greenLight, int time) {
prob1.setTimer(timer);
prob1.setWarnings(cruiseEngaged, distance);
assertEquals(redLight,prob1.isRedLight());
assertEquals(yellowLight,prob1.isYellowLight());
assertEquals(greenLight,prob1.isGreenLight());
assertEquals(time,prob1.getTimer());
}
}