package Code;

import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(JUnitParamsRunner.class)
public class logicalExpressionClassTest {

	logicalExpressionClass lex;
	
	@Before
	public void setUp() {
		lex = new logicalExpressionClass();
	}

	@SuppressWarnings("unused")
	private static final Object[] parametersForlogicalExpressionClassTest () {
		return $(
//				Parameters are: (1,2,3,4)
//								1=conditiona, 2=conditionb, 3=conditionc, 4=result
//				Test case 1
//				$(false,	true,		false, 	false),
//				Test case 2
//				$(true, 	true,		false, 	true),
//				Test case 3
//				$(true, 	false,		false, 	false),
//				Test case 4
				$(true, 	false,		true, 	true)
		);
	}
	@Test
	@Parameters(method="parametersForlogicalExpressionClassTest")
	public void test(boolean conditiona, boolean conditionb, boolean conditionc, boolean result) {
		assertEquals(result,lex.returnInput(conditiona,conditionb,conditionc));
	}
}