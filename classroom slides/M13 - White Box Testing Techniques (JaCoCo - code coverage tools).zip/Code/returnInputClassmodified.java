package Code;

public class returnInputClassmodified {

	public boolean returnInput(boolean conditiona, boolean conditionb, boolean conditionc) {

		  return (conditiona || conditionb || conditionc);
	}
}