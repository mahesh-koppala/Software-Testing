package Code;

public class Problem3Class {

	boolean Green_light, Yellow_light, Red_light, Chime;

	public boolean isGreen_light() {
		return Green_light;
	}

	public void setGreen_light(boolean green_light) {
		Green_light = green_light;
	}

	public boolean isYellow_light() {
		return Yellow_light;
	}

	public void setYellow_light(boolean yellow_light) {
		Yellow_light = yellow_light;
	}

	public boolean isRed_light() {
		return Red_light;
	}

	public void setRed_light(boolean red_light) {
		Red_light = red_light;
	}

	public boolean isChime() {
		return Chime;
	}

	public void setChime(boolean chime) {
		Chime = chime;
	}
	
	
}
