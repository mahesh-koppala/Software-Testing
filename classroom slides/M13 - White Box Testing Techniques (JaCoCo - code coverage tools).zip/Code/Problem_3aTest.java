package Code;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import junitparams.JUnitParamsRunner;

import org.junit.runner.RunWith;

import static junitparams.JUnitParamsRunner.$;
import junitparams.Parameters;

@RunWith(JUnitParamsRunner.class)
public class Problem_3aTest {

	Problem_3a prb3a;
	Problem3Class alerts;
	boolean red_light_actual,yellow_light_actual,green_light_actual;
	
	@Before
	public void setUp() {
		prb3a = new Problem_3a();
		alerts = new Problem3Class();
	}
	
	@SuppressWarnings("unused")
	private static final Object[] parametersForProblem_3aTest () {
		return $(
//					Parameters are: (1,2,3,4)
//							1=fuel_level, 2=red, 3=yellow, 4=green
//				Test case 1
				$(  10.0, false, 	false, 	true),
//				Test case 2
				$(  27.5, false, 	true, 	false),
//				Test case 3
				$(  50.0, true, 	false, 	false),
//				Test case 4
				$(  80.0, false, 	false, 	false)
		);
	}
	
	@Test
	@Parameters(method="parametersForProblem_3aTest")
	public void test (double fuel_level,boolean red_light, boolean yellow_light, boolean green_light)  {
		alerts.setRed_light(!red_light_actual);
		alerts.setYellow_light(!yellow_light_actual);
		alerts.setGreen_light(!green_light_actual);		
		// Default value of a boolean in Java is false
		prb3a.setAlerts(fuel_level, alerts);
		assertEquals(red_light,alerts.isRed_light());
		assertEquals(yellow_light,alerts.isYellow_light());
		assertEquals(green_light,alerts.isGreen_light());
		}
}